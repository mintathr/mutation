@extends('desk-layout.main')
@section('title', 'Account')
@section('subtitle', 'Account')
@section('content')


<livewire:account-index></livewire:account-index>




@endsection
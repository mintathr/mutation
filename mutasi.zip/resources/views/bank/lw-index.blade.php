@extends('desk-layout.main')
@section('title', 'Merchant')
@section('subtitle', 'Merchant')
@section('content')


<livewire:bank-index></livewire:bank-index>




@endsection
1. composer require realrashid/sweet-alert 
2. copas di header => @include('sweetalert::alert')
3. php artisan sweetalert:publish
4. 
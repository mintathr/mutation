<?php return array (
  'account-create' => 'App\\Http\\Livewire\\AccountCreate',
  'account-index' => 'App\\Http\\Livewire\\AccountIndex',
  'bank-create' => 'App\\Http\\Livewire\\BankCreate',
  'bank-index' => 'App\\Http\\Livewire\\BankIndex',
  'contact-create' => 'App\\Http\\Livewire\\ContactCreate',
  'contact-index' => 'App\\Http\\Livewire\\ContactIndex',
  'contact-update' => 'App\\Http\\Livewire\\ContactUpdate',
);
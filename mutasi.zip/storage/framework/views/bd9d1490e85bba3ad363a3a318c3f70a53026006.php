
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('subtitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>

<!-- Small boxes (Stat box) -->
<div class="row">
    <div class="col-lg-4 col-12">
        <!-- small box -->
        <div class="small-box bg-info">
            <div class="inner">
                <h3>Rp. <?php echo e(number_format($cek_sum_credit_today)); ?></h3>
                <p>SUM KREDIT</p>
            </div>
            <div class="icon">
                <i class="ion ion-cash"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>

    <div class="col-lg-4 col-12">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3>Rp. <?php echo e(number_format($cek_sum_debit_today)); ?></h3>

                <p>SUM DEBIT</p>
            </div>
            <div class="icon">
                <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-9">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Mutasi Hari Ini <?php echo e(date('d-M-Y', strtotime(now()))); ?></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>Sumber</th>
                                <th>Keterangan</th>
                                <th>Debit</th>
                                <th>Kredit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mutations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mutation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td>
                                    <?php echo e($mutation->bank->name); ?>

                                </td>
                                <td>
                                    <?php echo e($mutation->description); ?>

                                </td>
                                <td style="text-align: right;">
                                    <?php echo e(number_format($mutation->debit)); ?>

                                </td>
                                <td style="text-align: right;">
                                    <?php echo e(number_format($mutation->credit)); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/home.blade.php ENDPATH**/ ?>
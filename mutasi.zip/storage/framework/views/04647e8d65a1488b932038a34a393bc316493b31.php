<div>
    <?php if(session('sukses')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-check"></i> Sukses!</h5>
        <?php echo e(session('sukses')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('update')): ?>
    <div class="alert alert-info alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-info"></i> Sukses!</h5>
        <?php echo e(session('update')); ?>

    </div>
    <?php endif; ?>
    <!--<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-create', ['contacts' => $contacts])->html();
} elseif ($_instance->childHasBeenRendered('Vkslnmj')) {
    $componentId = $_instance->getRenderedChildComponentId('Vkslnmj');
    $componentTag = $_instance->getRenderedChildComponentTagName('Vkslnmj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Vkslnmj');
} else {
    $response = \Livewire\Livewire::mount('contact-create', ['contacts' => $contacts]);
    $html = $response->html();
    $_instance->logRenderedChild('Vkslnmj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-create>-->
    <?php if($statusUpdate): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-update', [])->html();
} elseif ($_instance->childHasBeenRendered('BLN0ZwC')) {
    $componentId = $_instance->getRenderedChildComponentId('BLN0ZwC');
    $componentTag = $_instance->getRenderedChildComponentTagName('BLN0ZwC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BLN0ZwC');
} else {
    $response = \Livewire\Livewire::mount('contact-update', []);
    $html = $response->html();
    $_instance->logRenderedChild('BLN0ZwC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-update>
    <?php else: ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-create', [])->html();
} elseif ($_instance->childHasBeenRendered('WHHQDyi')) {
    $componentId = $_instance->getRenderedChildComponentId('WHHQDyi');
    $componentTag = $_instance->getRenderedChildComponentTagName('WHHQDyi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('WHHQDyi');
} else {
    $response = \Livewire\Livewire::mount('contact-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('WHHQDyi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-create>
    <?php endif; ?>
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Table Contact</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
            <div class="row">
                <div class="col">
                    <select wire:model="paginate" name="" id="" class="form-control form-control-sm w-auto">
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="25">25</option>
                    </select>
                </div>
                <div class="col">
                    <input type="text" wire:model="search" name="" id="" class="form-control form-control-sm" placeholder="Search">

                </div>
            </div>
            <?php echo e($paginate); ?>

            <br>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($contact->name); ?></td>
                        <td><?php echo e($contact->phone); ?></td>
                        <td>
                            <button wire:click="getContact(<?php echo e($contact->id); ?>)" class="btn btn-sm btn-info text-white">Edit</button>
                            <button wire:click="destroy(<?php echo e($contact->id); ?>)" class="btn btn-sm btn-danger text-white">Delete</button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer clearfix">
            <?php echo e($contacts->links()); ?>

        </div>
    </div>

</div><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/livewire/contact-index.blade.php ENDPATH**/ ?>
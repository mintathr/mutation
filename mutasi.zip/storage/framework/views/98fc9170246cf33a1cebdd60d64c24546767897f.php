
<?php $__env->startSection('title', 'Account'); ?>
<?php $__env->startSection('subtitle', 'Account'); ?>
<?php $__env->startSection('content'); ?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account-index', [])->html();
} elseif ($_instance->childHasBeenRendered('IRPop4x')) {
    $componentId = $_instance->getRenderedChildComponentId('IRPop4x');
    $componentTag = $_instance->getRenderedChildComponentTagName('IRPop4x');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IRPop4x');
} else {
    $response = \Livewire\Livewire::mount('account-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('IRPop4x', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:account-index>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/account-merchant.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Transfer ' .$account->name); ?>
<?php $__env->startSection('subtitle', 'Transfer Rekening Dari ' .$account->name); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <div class="card card-primary">
        <div class="card-header">
            <h3 class="card-title">Form Transfer</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
            </div>
        </div>
        <form role="form" method="post" action="/mutation" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
            <input type="hidden" name="bank_id" value="<?php echo e($account->id); ?>">
            <input type="hidden" name="bank_name" value="<?php echo e($account->name); ?>">
            <input type="hidden" name="slug" value="<?php echo e($account->slug); ?>">
            <input type="hidden" name="nominal_kredit" value="0">
            <div class="card-body">
                <div class="form-group">
                    <label>Rekening Tujuan</label>
                    <select name="rek_tujuan" id="rek_tujuan" class="form-control select2bs4">
                        <option disabled selected>--Pilih--</option>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger mt-2">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="description">Keterangan</label>
                    <input type="text" name="description" id="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" oninput="this.value=this.value.replace(/[^A-Za-z0-9 ]/g,'');" placeholder="Keterangan" value="<?php echo e(old('description')); ?>">
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group">
                    <label for="debit">Debit</label>
                    <input type="text" name="debit" id="nominal_debit" class="form-control <?php $__errorArgs = ['debit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" oninput="this.value=this.value.replace(/[^0-9]/g,'');" placeholder="Debit" value="<?php echo e(old('debit')); ?>">
                    <?php $__errorArgs = ['debit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="date">tgl transaksi</label>
                    <input type="text" name="date" id="date" class="form-control date <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" date="" data-date-format="yyyy-mm-dd" placeholder="YYYY-MM-DD" value="<?php echo e(old('date')); ?>">
                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <h6 style="font-style: italic; color:red;">* Rekening Tujuan adalah rekening anda sendiri, yang otomatis akan bertambah.</h6>
                <h6 style="font-style: italic; color:red;">* Pilih Others bila Rekening Tujuan milik orang lain.</h6>
            </div>

            <!-- /.card-body -->
            <!-- /.card -->
            <div class="card-footer col-mb-3">
                <div class="float-left">
                    <button onclick="window.location.href='<?php echo e(url()->previous()); ?>';" type="button" class="btn btn-info"><i class="fa fa-arrow-left"></i>
                        Back
                    </button>
                </div>
                <div class="float-right">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#confirmation-modal"><i class="far fa-edit"></i>
                        Send
                    </button>
                </div>

                <div class="modal fade" id="confirmation-modal" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-body text-center font-18">
                                <h4 class="padding-top-30 mb-30 weight-500">Anda yakin transfer dana?</h4>
                                <div class="padding-bottom-30 row" style="max-width: 170px; margin: 0 auto;">
                                    <div class="col-6">
                                        <button type="button" class="btn btn-secondary border-radius-100 btn-block confirmation-btn" data-dismiss="modal"><i class="fa fa-times"></i></button>
                                        Tidak
                                    </div>
                                    <div class="col-6">
                                        <button type="submit" class="btn btn-primary border-radius-100 btn-block confirmation-btn"><i class="fa fa-check"></i></button>
                                        Ya
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/mutation/debit.blade.php ENDPATH**/ ?>
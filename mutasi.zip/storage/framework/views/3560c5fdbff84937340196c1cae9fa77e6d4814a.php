
<?php $__env->startSection('title', 'Merchant'); ?>
<?php $__env->startSection('subtitle', 'Merchant'); ?>
<?php $__env->startSection('content'); ?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bank-index', [])->html();
} elseif ($_instance->childHasBeenRendered('N4J0XF5')) {
    $componentId = $_instance->getRenderedChildComponentId('N4J0XF5');
    $componentTag = $_instance->getRenderedChildComponentTagName('N4J0XF5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('N4J0XF5');
} else {
    $response = \Livewire\Livewire::mount('bank-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('N4J0XF5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:bank-index>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/bank/lw-index.blade.php ENDPATH**/ ?>
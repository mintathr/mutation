
<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('subtitle', 'Register'); ?>
<?php $__env->startSection('content'); ?>

<div class="register-box">
    <div class="register-logo">
        <a href="../../index2.html"><b>Admin</b>RajaRenov</a>
    </div>

    <div class="card">
        <div class="card-body register-card-body">
            <?php if(session('errors')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                Something it's wrong:
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <p class="login-box-msg">Register a new membership</p>

            <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="input-group mb-3">
                    <input type="text" name="name" class="form-control" placeholder="Full name" value="<?php echo e(old('name')); ?>">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-user"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-envelope"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" value="<?php echo e(old('password')); ?>">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="password_confirmation" class="form-control" placeholder="Retype password">
                    <div class="input-group-append">
                        <div class="input-group-text">
                            <span class="fas fa-lock"></span>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Register</button>
            </form>

            <p class="mb-0">
                <a href="<?php echo e(route('login')); ?>" class="text-center">I already have a membership</a>
            </p>
        </div>
        <!-- /.form-box -->
    </div><!-- /.card -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main_login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/register.blade.php ENDPATH**/ ?>
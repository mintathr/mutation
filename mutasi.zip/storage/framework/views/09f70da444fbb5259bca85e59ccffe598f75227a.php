<div>
    <?php if(session('sukses')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-check"></i> Sukses!</h5>
        <?php echo e(session('sukses')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('gagal')): ?>
    <div class="alert alert-danger alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-info"></i> Gagal!</h5>
        <?php echo e(session('gagal')); ?>

    </div>
    <?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('account-create', [])->html();
} elseif ($_instance->childHasBeenRendered('AnmqfWf')) {
    $componentId = $_instance->getRenderedChildComponentId('AnmqfWf');
    $componentTag = $_instance->getRenderedChildComponentTagName('AnmqfWf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('AnmqfWf');
} else {
    $response = \Livewire\Livewire::mount('account-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('AnmqfWf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:account-create>

    <div class="row">
        <div class="card col-lg-6">
            <div class="card-header">
                <h3 class="card-title">Account</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col">
                    </div>
                    <div class="col">

                    </div>
                </div>
                <div class="mb-3"></div>
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Merchant</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($account->bank->name); ?></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4 offset md-4">

            </div>
        </div>
    </div>

    <script>
        window.livewire.on('alert', param => {
            toastr[param['type']](param['message'], param['type']);
        });
    </script>
</div><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/livewire/account-index.blade.php ENDPATH**/ ?>
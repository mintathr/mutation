<div>
    <div class="row">
        <div class="col-lg-6">
            <div class="card card-warning">
                <div class="card-header">
                    <h3 class="card-title">Tambah Merchant</h3>
                </div>
                <form wire:submit.prevent="store">
                    <div class="card-body">
                        <div class="form-group">
                            <label>Nama Merchant</label>
                            <select name="" wire:model="bank_id" id="bank" class="form-control" style="width: 100%;">
                                <option disabled selected>--Pilih--</option>
                                <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['bank_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-danger mt-2">
                                <?php echo e($message); ?>

                            </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="card-footer col-mb-3">
                        <div class="float-right">
                            <button type="submit" class="btn btn-primary"><i class="far fa-edit"></i>
                                Create
                            </button>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>


    <script>
        window.livewire.on('alert', param => {
            toastr[param['type']](param['message'], param['type']);
        });
    </script>
</div><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/livewire/account-create.blade.php ENDPATH**/ ?>
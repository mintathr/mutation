<div>
    <?php if(session('sukses')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-check"></i> Sukses!</h5>
        <?php echo e(session('sukses')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('update')): ?>
    <div class="alert alert-info alert-dismissible">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <h5><i class="icon fas fa-info"></i> Sukses!</h5>
        <?php echo e(session('update')); ?>

    </div>
    <?php endif; ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('bank-create', [])->html();
} elseif ($_instance->childHasBeenRendered('b5ShaxX')) {
    $componentId = $_instance->getRenderedChildComponentId('b5ShaxX');
    $componentTag = $_instance->getRenderedChildComponentTagName('b5ShaxX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('b5ShaxX');
} else {
    $response = \Livewire\Livewire::mount('bank-create', []);
    $html = $response->html();
    $_instance->logRenderedChild('b5ShaxX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:bank-create>

    <div class="row">
        <div class="card col-lg-6">
            <div class="card-header">
                <h3 class="card-title">List Bank</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="row">
                    <div class="col">
                        <select wire:model="paginate" name="" id="" class="form-control form-control-sm w-auto">
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="25">25</option>
                        </select>
                    </div>
                    <div class="col">
                        <input type="text" wire:model="search" name="" id="" class="form-control form-control-sm" placeholder="Search">

                    </div>
                </div>
                <div class="mb-3"></div>
                <table class="table">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($bank->name); ?></td>
                            <td><img src="/storage/<?php echo e($bank->file_img); ?>" style="width: 50px;height:50px;"></td>

                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4 offset md-4">
                <?php echo e($banks->links('link_pagination')); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/livewire/bank-index.blade.php ENDPATH**/ ?>
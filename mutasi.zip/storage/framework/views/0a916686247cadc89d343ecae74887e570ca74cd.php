
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('subtitle', 'Home'); ?>
<?php $__env->startSection('content'); ?>


<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact-index', [])->html();
} elseif ($_instance->childHasBeenRendered('N87X9ZV')) {
    $componentId = $_instance->getRenderedChildComponentId('N87X9ZV');
    $componentTag = $_instance->getRenderedChildComponentTagName('N87X9ZV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('N87X9ZV');
} else {
    $response = \Livewire\Livewire::mount('contact-index', []);
    $html = $response->html();
    $_instance->logRenderedChild('N87X9ZV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:contact-index>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/contact.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'List Funds'); ?>
<?php $__env->startSection('subtitle', 'List Funds'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .card {
        background-color: rgba(245, 245, 245, 0.4);
    }

    .card-header,
    .card-footer {
        opacity: 1
    }
</style>
<div class="container-fluid">
    <div class="row">
        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 justify-content-center">
            <div class="card">
                <div class="card-body">
                    <a href="/mutation/<?php echo e(Crypt::encryptString($account->bank->id)); ?>/<?php echo e($account->bank->slug); ?>"><img src="/storage/<?php echo e($account->bank->file_img); ?>" class="card-img-top" alt="..."></a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    </div>

</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/mutation/v_funds.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'User'); ?>
<?php $__env->startSection('subtitle', 'Data User'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('update')): ?>
<div class="alert alert-info alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><i class="icon fas fa-info"></i> Sukses!</h5>
    <?php echo e(session('update')); ?>

</div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Data User </h3>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Tanggal Create</th>
                        <th>Aktivasi</th>

                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($loop->iteration); ?>

                        </td>
                        <td>
                            <?php echo e($user->name); ?>

                        </td>
                        <td style="text-align: right;">
                            <?php echo e($user->email); ?>

                        </td>
                        <td style="text-align: right;">
                            <?php echo e($user->created_at); ?>

                        </td>
                        <td>
                            <?php if($user->role == ''): ?>
                            <form action="<?php echo e($user->id); ?>" method="post" class="d-inline">
                                <?php echo method_field('put'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-xs">Not Activate</button>
                            </form>
                            <?php else: ?>
                            <button type="button" class="btn btn-primary btn-xs">Activate</button>
                            <?php endif; ?>
                        </td>


                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/user/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Banks'); ?>
<?php $__env->startSection('subtitle', 'Banks'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('sukses')): ?>
<div class="alert alert-success alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><i class="icon fas fa-check"></i> Sukses!</h5>
    <?php echo e(session('sukses')); ?>

</div>
<?php endif; ?>
<?php if(session('update')): ?>
<div class="alert alert-info alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><i class="icon fas fa-info"></i> Sukses!</h5>
    <?php echo e(session('update')); ?>

</div>
<?php endif; ?>


<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">List Bank</h3>
                <div class="card-tools">
                    <a href="mutation/create" class="btn btn-primary btn-md"><i class="fa fa-plus"></i> Create</a>
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                        <i class="fas fa-minus"></i></button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <div class="table-responsive">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Funds</th>
                                <th>Credit</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td>
                                    <?php echo e($bank->name); ?>

                                </td>
                                <td>
                                    <?php echo e($bank->slug); ?>

                                </td>



                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('desk-layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Apache24\htdocs\mutasi\resources\views/bank/index.blade.php ENDPATH**/ ?>